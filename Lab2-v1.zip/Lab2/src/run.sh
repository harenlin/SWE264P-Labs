clear
rm *.class
javac *.java
java SystemMain ./../test_env/Students.txt ./../test_env/Courses.txt ./../test_env/log_file.txt
