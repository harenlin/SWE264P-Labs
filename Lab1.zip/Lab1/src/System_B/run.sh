rm *.class
clear
javac *.java
java Plumber ./OutputB.csv
