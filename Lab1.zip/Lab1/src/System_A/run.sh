rm *.class
clear
javac *.java
java Plumber ./OutputA.csv 5
